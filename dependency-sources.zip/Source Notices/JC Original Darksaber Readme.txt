================================================================================

		JC's Darksaber for K2			v1.2

================================================================================

								by JCarter426

================================================================================
    TABLE OF CONTENTS
================================================================================

1.  Summary
2.  Installation
3.  Uninstallation
4.  Compatibility
5.  Credits
6.  Distributing and Including This Mod
7.  Disclaimers
8.  Contact



================================================================================
1.  SUMMARY
================================================================================

This mod adds the Darksaber, a unique lightsaber seen in the Clone Wars and
Rebels TV shows, to Star Wars: Knights of the Old Republic II - The Sith Lords.

The Darksaber comes with a custom hilt and blade effect.

The Darksaber's stats are better than the standard lightsaber's (+2 Charisma and
+1d10 Universal damage) but the item cannot be upgraded.

I have integrated the item into the game, but I'll keep the how a surprise. One
hint: You must search through the possessions of a certain Mandalorian.

If you want to get it through playing the game, you'll have to start a new game.
Otherwise, you can cheat it in. The item is "jc_darksaber".



================================================================================
2.  INSTALLATION
================================================================================

1. Copy the files in the Override folder to your own Override folder (if you
   don't have one, make one).



================================================================================
3.  UNINSTALLATION
================================================================================

1. Remove the installed files.



================================================================================
4.  COMPATIBILITY
================================================================================

Compatibility with other lightsaber mods not guaranteed.

This mod uses lightsaber model variation 255.

The file a_meetmand_cs.ncs places the Darksaber into the game. If you have any
compatibility issues with other mods that edit that file, you can skip it and
cheat the item into the game instead. The Darksaber item is "jc_darksaber".



================================================================================
5.  CREDITS
================================================================================

KOTOR Tool		Fred Tetra
NWMax			Joco
KOTORMax & MDLEdit	bead-v
tga2tpc			ndix UR
NWNSSCOMP		Torlack, stoffe, & tk102
DeNCS			JdNoa & Dashus
Saber			Andrew Kramer & VideoCopilot.net


================================================================================
6.  DISTRIBUTING AND INCLUDING THIS MOD
================================================================================

I hereby grant nobody except myself permission to upload some or all of this mod
anywhere for any reason. For any reason.

If you would like to include any part of this mod in anything, then please
contact me for permission.



================================================================================
7.  DISCLAIMERS
================================================================================

WARNING: THERMODYNAMIC LAW VIOLATIONS WILL RESULT IN THE SUMMONING OF MAXWELL'S
DEMON. TO BANISH IT, YOU WILL HAVE TO DEFEAT THE ORIGINAL CASTER AND DISMANTLE
THE SUMMONING CIRCLE, HIDDEN IN THE DUNGEONS OF LUCASFILM. MAY THE FORCE BE WITH
YOU.



================================================================================
8. CONTACT
================================================================================

Questions? Problems? Suggestions? Something else?

Email me at kotor.hexATgmailDOTcom or PM me on Deadly Stream or wherever else 
you can find me.